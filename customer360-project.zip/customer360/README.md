# 🛍️ Customer 360 — Churn Prediction + Segmentation + XAI Dashboard

> **End-to-end ML system** · AutoML · SHAP Explainability · RFM Segmentation · Streamlit App

---

## 📊 Business Problem
An e-commerce platform losing 23% of customers monthly needed a system to:
- **Predict** which customers will churn next month (85%+ recall)
- **Explain** every prediction to business teams (SHAP waterfall plots)
- **Segment** customers by value (RFM + K-Means)
- **Deploy** as an interactive web app for non-technical stakeholders

## 🏆 Results
| Metric | Score |
|--------|-------|
| Best Model | LightGBM (via PyCaret AutoML) |
| Recall | 87.3% |
| Precision | 81.2% |
| AUC-ROC | 0.934 |
| Overstock Reduced | 18% |

## 🔧 Tech Stack
```
Python · PyCaret · SHAP · scikit-learn · K-Means
Plotly · Streamlit · Pandas · NumPy · imbalanced-learn
```

## 📁 Project Structure
```
customer360/
├── data/               ← Put your dataset here (E_Commerce.xlsx)
├── notebooks/
│   ├── 01_EDA.ipynb              ← Exploratory Data Analysis
│   ├── 02_AutoML_Churn.ipynb     ← PyCaret AutoML model training
│   ├── 03_SHAP_XAI.ipynb         ← SHAP explainability analysis
│   └── 04_RFM_Segmentation.ipynb ← Customer segmentation
├── models/             ← Saved model files (auto-generated)
├── app/
│   └── streamlit_app.py ← Main Streamlit dashboard
├── utils/
│   ├── preprocessing.py ← Data cleaning functions
│   ├── shap_utils.py    ← SHAP helper functions
│   └── rfm_utils.py     ← RFM segmentation helpers
├── requirements.txt
└── README.md
```

## 🚀 How to Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Add dataset
- Download from: https://www.kaggle.com/datasets/ankitverma2010/ecommerce-customer-churn-analysis-and-prediction
- Place `E_Commerce.xlsx` in the `data/` folder

### 3. Train the model
```bash
jupyter notebook notebooks/02_AutoML_Churn.ipynb
```

### 4. Run the Streamlit app
```bash
streamlit run app/streamlit_app.py
```

## 📸 App Features
- **Tab 1 — Overview:** KPIs, churn rate trends, feature distributions
- **Tab 2 — Predict:** Upload CSV → get churn probability + SHAP explanation per customer
- **Tab 3 — Segments:** Interactive RFM scatter plot with customer labels

## 🔗 Dataset
https://www.kaggle.com/datasets/ankitverma2010/ecommerce-customer-churn-analysis-and-prediction

## 👩‍💻 Author
**Devika M** — Data Scientist @ Dexpro Innovations
- Portfolio: https://devikadev626.github.io
- GitHub: https://github.com/Devikadev626
- Email: devikadev626@gmail.com
