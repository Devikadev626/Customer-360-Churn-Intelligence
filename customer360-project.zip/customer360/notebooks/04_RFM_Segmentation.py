"""
notebooks/04_RFM_Segmentation.py
RFM Customer Segmentation for Customer 360 project
Run: python notebooks/04_RFM_Segmentation.py
"""

import os, sys, warnings
warnings.filterwarnings('ignore')
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import joblib

from utils.preprocessing import load_data, handle_missing_values
from utils.rfm_utils import (compute_rfm, find_optimal_k,
                              apply_kmeans_segmentation, plot_rfm_2d_scatter,
                              plot_segment_donut, get_segment_action_plan)

DATA_PATH  = 'data/E_Commerce.xlsx'
MODEL_DIR  = 'models/'
os.makedirs(MODEL_DIR, exist_ok=True)

print("=" * 55)
print("  👥  CUSTOMER 360 — RFM Segmentation")
print("=" * 55)

# ── Load & Prep ─────────────────────────────
df = load_data(DATA_PATH)
df = handle_missing_values(df)

# Add CustomerID if not present
if 'CustomerID' not in df.columns:
    df['CustomerID'] = range(1, len(df)+1)

# ── Compute RFM ─────────────────────────────
print("\n📊 Computing RFM scores...")
rfm = compute_rfm(df)

print("\n📋 RFM Statistics:")
print(rfm[['Recency', 'Frequency', 'Monetary', 'RFM_Score']].describe().round(2))

# ── Find Optimal Clusters ───────────────────
print("\n🔍 Finding optimal number of clusters...")
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
rfm_scaled = scaler.fit_transform(rfm[['Recency', 'Frequency', 'Monetary']])
optimal_k = find_optimal_k(rfm_scaled)
print(f"   Recommended clusters: {optimal_k}")

# ── Apply Segmentation ──────────────────────
print(f"\n🎯 Applying K-Means with k={optimal_k}...")
rfm_segmented, rfm_scaler, rfm_kmeans = apply_kmeans_segmentation(rfm, n_clusters=4)

# ── Save Models ─────────────────────────────
joblib.dump(rfm_segmented, f'{MODEL_DIR}rfm_segments.pkl')
joblib.dump(rfm_scaler,    f'{MODEL_DIR}rfm_scaler.pkl')
joblib.dump(rfm_kmeans,    f'{MODEL_DIR}rfm_kmeans.pkl')
print(f"\n✅ Segmentation saved to {MODEL_DIR}")

# ── Visualisations ──────────────────────────
print("\n📈 Generating visualisation plots...")

# 2D scatter
fig_scatter = plot_rfm_2d_scatter(rfm_segmented)
fig_scatter.write_image(f'{MODEL_DIR}rfm_2d_scatter.png')
print(f"  ✅ 2D scatter: {MODEL_DIR}rfm_2d_scatter.png")

# Segment summary bar chart
fig, axes = plt.subplots(1, 3, figsize=(15, 5))
fig.suptitle('RFM Segment Profiles', fontsize=14, fontweight='bold')

metrics  = ['Recency', 'Frequency', 'Monetary']
palettes = ['#f43f5e', '#2563eb', '#10b981']

for ax, metric, color in zip(axes, metrics, palettes):
    seg_means = rfm_segmented.groupby('Segment')[metric].mean().sort_values()
    bars = ax.barh(seg_means.index, seg_means.values,
                   color=color, alpha=0.8, edgecolor='white')
    ax.set_title(f'Avg {metric} by Segment', fontweight='bold')
    ax.spines[['top', 'right']].set_visible(False)
    for bar, val in zip(bars, seg_means.values):
        ax.text(val + max(seg_means)*0.01, bar.get_y() + bar.get_height()/2,
                f'{val:.1f}', va='center', fontsize=9)

plt.tight_layout()
plt.savefig(f'{MODEL_DIR}rfm_segment_profiles.png', dpi=150, bbox_inches='tight')
print(f"  ✅ Segment profiles: {MODEL_DIR}rfm_segment_profiles.png")

# ── Action Plan ─────────────────────────────
print("\n" + "=" * 55)
print("  🎯  SEGMENT ACTION PLAN")
print("=" * 55)

action_plan = get_segment_action_plan()
for seg, plan in action_plan.items():
    count = (rfm_segmented['Segment'] == seg).sum()
    pct   = count / len(rfm_segmented) * 100
    print(f"\n  {seg}")
    print(f"    Count    : {count:,} customers ({pct:.1f}%)")
    print(f"    Priority : {plan['priority']}")
    print(f"    Action   : {plan['action'][:80]}...")

print("\n" + "=" * 55)
print("  ✅  RFM Segmentation complete!")
print("  Run the Streamlit app to see interactive results:")
print("  streamlit run app/streamlit_app.py")
print("=" * 55)
