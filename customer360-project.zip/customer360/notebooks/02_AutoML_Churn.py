"""
notebooks/02_AutoML_Churn.py
PyCaret AutoML training pipeline for Customer 360 churn prediction.
Run this script to train, evaluate and save the best model.

Usage: python notebooks/02_AutoML_Churn.py
"""

import os
import sys
import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.preprocessing import full_preprocessing_pipeline
from utils.shap_utils import (get_shap_explainer, compute_shap_values,
                               plot_global_importance, generate_shap_report)


# ─────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────
DATA_PATH   = 'data/E_Commerce.xlsx'
MODEL_DIR   = 'models/'
TARGET_COL  = 'Churn'
RANDOM_SEED = 42
TEST_SIZE   = 0.20

os.makedirs(MODEL_DIR, exist_ok=True)

print("=" * 60)
print("  🛍️  CUSTOMER 360 — AutoML Churn Model Training")
print("=" * 60)


# ─────────────────────────────────────────────
#  STEP 1: LOAD & PREPROCESS
# ─────────────────────────────────────────────
print("\n📦 STEP 1: Loading and preprocessing data...")

df, X, y, feature_names = full_preprocessing_pipeline(DATA_PATH)

print(f"\n📊 Class distribution:")
print(f"   Non-Churn (0): {(y==0).sum()} ({(y==0).mean()*100:.1f}%)")
print(f"   Churn     (1): {(y==1).sum()} ({(y==1).mean()*100:.1f}%)")


# ─────────────────────────────────────────────
#  STEP 2: PYCARET AUTOML SETUP
# ─────────────────────────────────────────────
print("\n🤖 STEP 2: Setting up PyCaret AutoML...")

try:
    from pycaret.classification import (
        setup, compare_models, pull, save_model,
        load_model, predict_model, plot_model,
        get_config, finalize_model, tune_model
    )

    # PyCaret setup — this is the magic one-liner!
    clf = setup(
        data        = df,
        target      = TARGET_COL,
        session_id  = RANDOM_SEED,
        train_size  = 1 - TEST_SIZE,

        # Handle class imbalance automatically
        fix_imbalance      = True,
        fix_imbalance_method = 'smote',

        # Preprocessing
        normalize          = True,
        normalize_method   = 'minmax',
        remove_multicollinearity = True,
        multicollinearity_threshold = 0.95,

        # Speed settings
        fold                = 5,
        fold_strategy       = 'stratifiedkfold',

        # Silent mode
        verbose            = False,
        html               = False,
    )

    print("✅ PyCaret setup complete!")


    # ─────────────────────────────────────────────
    #  STEP 3: COMPARE ALL MODELS (AutoML)
    # ─────────────────────────────────────────────
    print("\n⚡ STEP 3: Comparing models (AutoML)...")
    print("   This will train and evaluate 15+ models automatically...")
    print("   Optimising for: Recall (most important for churn)")

    best_model = compare_models(
        sort        = 'Recall',   # Prioritise recall for churn
        n_select    = 1,
        exclude     = ['catboost'],  # Exclude slow models for demo
        verbose     = False
    )

    # Print comparison table
    comparison_df = pull()
    print("\n📊 Model Comparison Results:")
    print(comparison_df[['Model', 'AUC', 'Recall', 'Precision', 'F1',
                          'Accuracy']].to_string(index=False))


    # ─────────────────────────────────────────────
    #  STEP 4: TUNE THE BEST MODEL
    # ─────────────────────────────────────────────
    print("\n🎯 STEP 4: Tuning the best model...")
    tuned_model = tune_model(
        best_model,
        optimize   = 'Recall',
        n_iter     = 20,
        verbose    = False
    )

    tuned_results = pull()
    print("\n📊 Tuned Model Performance:")
    print(f"   AUC       : {tuned_results['AUC'].mean():.4f}")
    print(f"   Recall    : {tuned_results['Recall'].mean():.4f}")
    print(f"   Precision : {tuned_results['Precision'].mean():.4f}")
    print(f"   F1 Score  : {tuned_results['F1'].mean():.4f}")
    print(f"   Accuracy  : {tuned_results['Accuracy'].mean():.4f}")


    # ─────────────────────────────────────────────
    #  STEP 5: SAVE MODEL
    # ─────────────────────────────────────────────
    print("\n💾 STEP 5: Saving model...")
    finalized_model = finalize_model(tuned_model)
    save_model(finalized_model, f'{MODEL_DIR}churn_model_pycaret')
    print(f"✅ Model saved to: {MODEL_DIR}churn_model_pycaret.pkl")

    # Save comparison table
    comparison_df.to_csv(f'{MODEL_DIR}model_comparison.csv', index=False)
    print(f"✅ Comparison saved to: {MODEL_DIR}model_comparison.csv")


    # ─────────────────────────────────────────────
    #  STEP 6: SHAP EXPLAINABILITY
    # ─────────────────────────────────────────────
    print("\n🔍 STEP 6: Computing SHAP values...")

    # Get test data
    X_train_pycaret = get_config('X_train')
    X_test_pycaret  = get_config('X_test')

    # Extract the actual sklearn model from PyCaret pipeline
    from sklearn.pipeline import Pipeline
    if isinstance(finalized_model, Pipeline):
        actual_model = finalized_model.steps[-1][1]
        X_test_transformed = finalized_model[:-1].transform(X_test_pycaret)
        X_train_transformed = finalized_model[:-1].transform(X_train_pycaret)
    else:
        actual_model = finalized_model
        X_test_transformed  = X_test_pycaret
        X_train_transformed = X_train_pycaret

    explainer   = get_shap_explainer(actual_model, X_train_transformed)
    shap_values = compute_shap_values(explainer, X_test_transformed)

    # Generate and save SHAP plots
    if isinstance(X_test_transformed, np.ndarray):
        X_test_df = pd.DataFrame(X_test_transformed,
                                  columns=X_test_pycaret.columns)
    else:
        X_test_df = X_test_transformed

    shap_paths = generate_shap_report(explainer, shap_values,
                                       X_test_df, save_dir=MODEL_DIR)
    print(f"✅ SHAP plots saved: {list(shap_paths.keys())}")


    # ─────────────────────────────────────────────
    #  STEP 7: SAVE EXPLAINER & TEST DATA
    # ─────────────────────────────────────────────
    import joblib
    joblib.dump(explainer,   f'{MODEL_DIR}shap_explainer.pkl')
    joblib.dump(X_test_df,   f'{MODEL_DIR}X_test_sample.pkl')
    joblib.dump(feature_names, f'{MODEL_DIR}feature_names.pkl')
    print(f"✅ SHAP explainer and test data saved.")


except ImportError:
    print("\n⚠️  PyCaret not installed. Running with scikit-learn fallback...")
    _run_sklearn_fallback(df, X, y, feature_names, MODEL_DIR, RANDOM_SEED, TEST_SIZE)


# ─────────────────────────────────────────────
#  SKLEARN FALLBACK (if PyCaret not available)
# ─────────────────────────────────────────────
def _run_sklearn_fallback(df, X, y, feature_names, MODEL_DIR,
                           RANDOM_SEED, TEST_SIZE):
    """Fallback training using scikit-learn directly."""
    from sklearn.model_selection import train_test_split, cross_val_score
    from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import (classification_report, roc_auc_score,
                                  confusion_matrix)
    from sklearn.preprocessing import StandardScaler
    from imblearn.over_sampling import SMOTE
    import joblib

    print("\n🔧 Running sklearn fallback training...")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_SEED, stratify=y)

    # Balance with SMOTE
    smote = SMOTE(random_state=RANDOM_SEED)
    X_train_res, y_train_res = smote.fit_resample(X_train, y_train)

    # Scale
    scaler = StandardScaler()
    X_train_sc = scaler.fit_transform(X_train_res)
    X_test_sc  = scaler.transform(X_test)

    # Train multiple models
    models = {
        'RandomForest': RandomForestClassifier(n_estimators=200, random_state=RANDOM_SEED,
                                                class_weight='balanced'),
        'GradientBoosting': GradientBoostingClassifier(n_estimators=200,
                                                        random_state=RANDOM_SEED),
        'LogisticRegression': LogisticRegression(max_iter=1000, random_state=RANDOM_SEED,
                                                  class_weight='balanced')
    }

    best_recall = 0
    best_name   = None
    best_clf    = None
    results     = {}

    for name, clf in models.items():
        clf.fit(X_train_sc, y_train_res)
        y_pred = clf.predict(X_test_sc)
        y_prob = clf.predict_proba(X_test_sc)[:, 1]

        report = classification_report(y_test, y_pred, output_dict=True)
        auc    = roc_auc_score(y_test, y_prob)

        recall = report['1']['recall']
        results[name] = {
            'Recall': recall, 'Precision': report['1']['precision'],
            'F1': report['1']['f1-score'], 'AUC': auc,
            'Accuracy': report['accuracy']
        }

        print(f"\n  {name}:")
        print(f"    Recall={recall:.3f}  Precision={report['1']['precision']:.3f}"
              f"  AUC={auc:.3f}")

        if recall > best_recall:
            best_recall = recall
            best_name   = name
            best_clf    = clf

    print(f"\n🏆 Best model: {best_name} (Recall={best_recall:.3f})")

    # Save best model
    joblib.dump(best_clf,  f'{MODEL_DIR}churn_model_sklearn.pkl')
    joblib.dump(scaler,    f'{MODEL_DIR}scaler.pkl')
    joblib.dump(feature_names, f'{MODEL_DIR}feature_names.pkl')
    pd.DataFrame(results).T.to_csv(f'{MODEL_DIR}model_comparison.csv')
    print(f"✅ Sklearn model saved to {MODEL_DIR}")

    # SHAP on best model
    try:
        import shap, joblib as jl
        from utils.shap_utils import get_shap_explainer, compute_shap_values, generate_shap_report

        X_test_df = pd.DataFrame(X_test_sc, columns=feature_names)
        explainer = get_shap_explainer(best_clf, pd.DataFrame(X_train_sc, columns=feature_names))
        shap_vals = compute_shap_values(explainer, X_test_df)

        generate_shap_report(explainer, shap_vals, X_test_df, save_dir=MODEL_DIR)
        jl.dump(explainer, f'{MODEL_DIR}shap_explainer.pkl')
        jl.dump(X_test_df, f'{MODEL_DIR}X_test_sample.pkl')
        print("✅ SHAP analysis complete.")
    except Exception as e:
        print(f"⚠️  SHAP failed: {e}")


print("\n" + "=" * 60)
print("  ✅ Training Complete! Run the Streamlit app next:")
print("  streamlit run app/streamlit_app.py")
print("=" * 60)
