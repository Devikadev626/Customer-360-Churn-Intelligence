"""
notebooks/01_EDA.py
Exploratory Data Analysis for Customer 360 Churn Project
Run: python notebooks/01_EDA.py
"""

import os, sys, warnings
warnings.filterwarnings('ignore')
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')
import seaborn as sns
import plotly.express as px
from utils.preprocessing import load_data, handle_missing_values

# ── Config ──────────────────────────────────
DATA_PATH  = 'data/E_Commerce.xlsx'
PLOTS_DIR  = 'models/eda_plots/'
os.makedirs(PLOTS_DIR, exist_ok=True)
plt.style.use('seaborn-v0_8-whitegrid')
COLORS = {'churn': '#f43f5e', 'no_churn': '#10b981', 'blue': '#2563eb'}

print("=" * 55)
print("  📊  CUSTOMER 360 — Exploratory Data Analysis")
print("=" * 55)

# ── Load Data ───────────────────────────────
df = load_data(DATA_PATH)
df = handle_missing_values(df)

print(f"\n📋 Dataset Summary:")
print(df.describe().round(2))

# ── 1. Churn Distribution ───────────────────
fig, axes = plt.subplots(1, 2, figsize=(13, 5))
fig.suptitle('Churn Distribution Analysis', fontsize=14, fontweight='bold', y=1.02)

# Pie chart
churn_counts = df['Churn'].value_counts()
axes[0].pie(churn_counts.values, labels=['Non-Churn', 'Churn'],
            colors=[COLORS['no_churn'], COLORS['churn']],
            autopct='%1.1f%%', startangle=90,
            wedgeprops={'edgecolor': 'white', 'linewidth': 2})
axes[0].set_title('Overall Churn Rate', fontweight='bold')

# By tenure
if 'Tenure' in df.columns:
    df['Tenure_Group'] = pd.cut(df['Tenure'], bins=[0, 6, 12, 24, 72],
                                  labels=['0–6m', '6–12m', '12–24m', '24m+'])
    tenure_churn = df.groupby('Tenure_Group')['Churn'].mean() * 100
    bars = axes[1].bar(tenure_churn.index.astype(str), tenure_churn.values,
                        color=[COLORS['churn'] if v > 20 else COLORS['no_churn']
                               for v in tenure_churn.values],
                        edgecolor='white', linewidth=1.5)
    axes[1].set_xlabel('Tenure Group', fontsize=11)
    axes[1].set_ylabel('Churn Rate (%)', fontsize=11)
    axes[1].set_title('Churn Rate by Customer Tenure', fontweight='bold')
    for bar, val in zip(bars, tenure_churn.values):
        axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                     f'{val:.1f}%', ha='center', fontsize=10, fontweight='bold')
    axes[1].spines[['top', 'right']].set_visible(False)

plt.tight_layout()
plt.savefig(f'{PLOTS_DIR}01_churn_distribution.png', dpi=150, bbox_inches='tight')
print(f"✅ Saved: {PLOTS_DIR}01_churn_distribution.png")

# ── 2. Feature Correlation ──────────────────
numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
if len(numeric_cols) > 2:
    fig, ax = plt.subplots(figsize=(14, 10))
    corr_matrix = df[numeric_cols].corr()
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
    sns.heatmap(corr_matrix, mask=mask, annot=True, fmt='.2f', cmap='RdBu_r',
                center=0, ax=ax, square=True, linewidths=0.5,
                annot_kws={'size': 8}, vmin=-1, vmax=1)
    ax.set_title('Feature Correlation Matrix', fontsize=13, fontweight='bold', pad=15)
    plt.tight_layout()
    plt.savefig(f'{PLOTS_DIR}02_correlation_heatmap.png', dpi=150, bbox_inches='tight')
    print(f"✅ Saved: {PLOTS_DIR}02_correlation_heatmap.png")

# ── 3. Key Categorical Features vs Churn ────
cat_features = [c for c in ['PreferredPaymentMode', 'PreferedOrderCat',
                              'MaritalStatus', 'Gender'] if c in df.columns]
if cat_features:
    n = len(cat_features)
    fig, axes = plt.subplots(1, min(n, 2), figsize=(14, 5))
    if n == 1: axes = [axes]

    for ax, feat in zip(axes, cat_features[:2]):
        churn_by_feat = df.groupby(feat)['Churn'].mean() * 100
        bars = ax.barh(churn_by_feat.index, churn_by_feat.values,
                       color=[COLORS['churn'] if v > 20 else COLORS['blue']
                              for v in churn_by_feat.values],
                       edgecolor='white')
        ax.set_xlabel('Churn Rate (%)', fontsize=11)
        ax.set_title(f'Churn Rate by {feat}', fontweight='bold')
        ax.spines[['top', 'right']].set_visible(False)
        for bar, val in zip(bars, churn_by_feat.values):
            ax.text(val + 0.3, bar.get_y() + bar.get_height()/2,
                    f'{val:.1f}%', va='center', fontsize=9)

    plt.suptitle('Churn Rate by Categorical Features', fontsize=13,
                  fontweight='bold', y=1.02)
    plt.tight_layout()
    plt.savefig(f'{PLOTS_DIR}03_categorical_churn.png', dpi=150, bbox_inches='tight')
    print(f"✅ Saved: {PLOTS_DIR}03_categorical_churn.png")

# ── 4. Numeric Feature Distributions ────────
num_feats = [c for c in ['Tenure', 'CashbackAmount', 'OrderCount',
                          'DaySinceLastOrder', 'SatisfactionScore'] if c in df.columns]
if num_feats:
    fig, axes = plt.subplots(1, len(num_feats), figsize=(16, 4))
    for ax, feat in zip(axes, num_feats):
        churned     = df[df['Churn'] == 1][feat].dropna()
        not_churned = df[df['Churn'] == 0][feat].dropna()
        ax.hist(not_churned, bins=25, alpha=0.7, color=COLORS['no_churn'],
                label='No Churn', density=True)
        ax.hist(churned, bins=25, alpha=0.7, color=COLORS['churn'],
                label='Churn', density=True)
        ax.set_xlabel(feat, fontsize=10)
        ax.set_ylabel('Density', fontsize=10)
        ax.set_title(feat, fontweight='bold', fontsize=11)
        ax.spines[['top', 'right']].set_visible(False)
        if feat == num_feats[0]:
            ax.legend(fontsize=9)

    plt.suptitle('Feature Distributions: Churn vs Non-Churn',
                  fontsize=13, fontweight='bold', y=1.02)
    plt.tight_layout()
    plt.savefig(f'{PLOTS_DIR}04_feature_distributions.png', dpi=150, bbox_inches='tight')
    print(f"✅ Saved: {PLOTS_DIR}04_feature_distributions.png")

# ── 5. Key Insights Summary ─────────────────
print("\n" + "=" * 55)
print("  🔍  KEY INSIGHTS FROM EDA")
print("=" * 55)
churn_rate = df['Churn'].mean() * 100
print(f"\n  1. Overall Churn Rate     : {churn_rate:.1f}%")

if 'SatisfactionScore' in df.columns:
    low_sat_churn = df[df['SatisfactionScore'] <= 2]['Churn'].mean() * 100
    print(f"  2. Churn (Satisfaction ≤2) : {low_sat_churn:.1f}% "
          f"(vs {churn_rate:.1f}% overall)")

if 'Complain' in df.columns:
    complain_churn = df[df['Complain'] == 1]['Churn'].mean() * 100
    print(f"  3. Churn (Has Complained)  : {complain_churn:.1f}%")

if 'Tenure' in df.columns:
    early_churn = df[df['Tenure'] < 6]['Churn'].mean() * 100
    print(f"  4. Churn (Tenure < 6mo)    : {early_churn:.1f}%")

if 'CashbackAmount' in df.columns:
    low_cb_churn = df[df['CashbackAmount'] < df['CashbackAmount'].quantile(0.25)]['Churn'].mean() * 100
    print(f"  5. Churn (Low Cashback)    : {low_cb_churn:.1f}%")

print(f"\n  📁 All plots saved to: {PLOTS_DIR}")
print("=" * 55)
print("\n  ✅ EDA complete! Next: run 02_AutoML_Churn.py")
