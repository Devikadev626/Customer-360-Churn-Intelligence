"""
app/streamlit_app.py
Customer 360 — Churn Prediction + Segmentation + XAI Dashboard
Run: streamlit run app/streamlit_app.py
"""

import os
import sys
import warnings
warnings.filterwarnings('ignore')

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import joblib
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.rfm_utils import (compute_rfm, apply_kmeans_segmentation,
                               plot_rfm_2d_scatter, plot_segment_donut,
                               get_segment_action_plan)
from utils.shap_utils import (get_customer_shap_explanation,
                               plot_waterfall_single_customer)

# ─────────────────────────────────────────────
#  PAGE CONFIG
# ─────────────────────────────────────────────
st.set_page_config(
    page_title="Customer 360 | Churn AI",
    page_icon="🛍️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─────────────────────────────────────────────
#  CUSTOM CSS
# ─────────────────────────────────────────────
st.markdown("""
<style>
    /* Main background */
    .main { background-color: #f8fafc; }
    .stApp { background-color: #f8fafc; }

    /* Metric cards */
    div[data-testid="metric-container"] {
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 1rem 1.25rem;
        box-shadow: 0 1px 6px rgba(0,0,0,0.05);
    }

    /* Header */
    .hero-header {
        background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%);
        padding: 2rem 2.5rem;
        border-radius: 16px;
        margin-bottom: 2rem;
    }
    .hero-title {
        font-size: 2rem; font-weight: 800;
        color: white; margin: 0; letter-spacing: -0.03em;
    }
    .hero-sub {
        color: #38bdf8; font-size: 0.9rem; margin-top: 0.25rem;
    }
    .hero-badges { margin-top: 0.75rem; }
    .badge {
        display: inline-block; padding: 3px 12px;
        border-radius: 100px; font-size: 0.72rem;
        font-weight: 500; margin-right: 6px;
    }
    .badge-blue { background: rgba(56,189,248,0.2); color: #38bdf8; }
    .badge-green { background: rgba(16,185,129,0.2); color: #10b981; }
    .badge-purple { background: rgba(139,92,246,0.2); color: #8b5cf6; }

    /* Section headers */
    .section-title {
        font-size: 1.2rem; font-weight: 700;
        color: #0f172a; margin-bottom: 1rem;
        border-left: 3px solid #2563eb;
        padding-left: 0.75rem;
    }

    /* Churn indicator */
    .churn-high {
        background: #fef2f2; border: 1px solid #fecaca;
        border-radius: 10px; padding: 1rem; text-align: center;
        color: #dc2626;
    }
    .churn-low {
        background: #f0fdf4; border: 1px solid #bbf7d0;
        border-radius: 10px; padding: 1rem; text-align: center;
        color: #16a34a;
    }

    /* Hide Streamlit branding */
    #MainMenu { visibility: hidden; }
    footer { visibility: hidden; }

    /* Tabs */
    .stTabs [data-baseweb="tab-list"] { gap: 8px; }
    .stTabs [data-baseweb="tab"] {
        border-radius: 8px; padding: 8px 20px;
        font-weight: 500;
    }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
#  LOAD ASSETS (model, explainer, sample data)
# ─────────────────────────────────────────────
@st.cache_resource(show_spinner=False)
def load_model_assets():
    """Load trained model and SHAP explainer."""
    model_dir = 'models/'
    assets = {}

    # Try loading PyCaret model first
    try:
        from pycaret.classification import load_model as pc_load
        assets['model'] = pc_load(f'{model_dir}churn_model_pycaret')
        assets['model_type'] = 'pycaret'
    except Exception:
        try:
            assets['model'] = joblib.load(f'{model_dir}churn_model_sklearn.pkl')
            assets['scaler'] = joblib.load(f'{model_dir}scaler.pkl')
            assets['model_type'] = 'sklearn'
        except Exception:
            assets['model'] = None
            assets['model_type'] = 'none'

    # Load SHAP explainer
    try:
        assets['explainer'] = joblib.load(f'{model_dir}shap_explainer.pkl')
        assets['X_test']    = joblib.load(f'{model_dir}X_test_sample.pkl')
    except Exception:
        assets['explainer'] = None
        assets['X_test']    = None

    # Load feature names
    try:
        assets['feature_names'] = joblib.load(f'{model_dir}feature_names.pkl')
    except Exception:
        assets['feature_names'] = None

    # Load model comparison
    try:
        assets['comparison'] = pd.read_csv(f'{model_dir}model_comparison.csv')
    except Exception:
        assets['comparison'] = None

    return assets


@st.cache_data(show_spinner=False)
def load_sample_data():
    """Load or generate sample data for demo."""
    data_path = 'data/E_Commerce.xlsx'
    if os.path.exists(data_path):
        try:
            df = pd.read_excel(data_path, sheet_name='E Comm')
            return df
        except Exception:
            pass

    # Generate realistic synthetic data for demo
    np.random.seed(42)
    n = 5630
    df = pd.DataFrame({
        'CustomerID'            : range(1, n+1),
        'Churn'                 : np.random.choice([0, 1], n, p=[0.83, 0.17]),
        'Tenure'                : np.random.exponential(12, n).clip(0, 60).astype(int),
        'CityTier'              : np.random.choice([1, 2, 3], n, p=[0.4, 0.35, 0.25]),
        'WarehouseToHome'       : np.random.randint(5, 35, n),
        'HourSpendOnApp'        : np.random.choice([1, 2, 3, 4, 5], n),
        'NumberOfDeviceRegistered': np.random.choice([1, 2, 3, 4, 5, 6], n),
        'SatisfactionScore'     : np.random.choice([1, 2, 3, 4, 5], n),
        'NumberOfAddress'       : np.random.randint(1, 8, n),
        'Complain'              : np.random.choice([0, 1], n, p=[0.85, 0.15]),
        'OrderAmountHikeFromlastYear': np.random.normal(15, 5, n).clip(5, 30),
        'CouponUsed'            : np.random.randint(0, 8, n),
        'OrderCount'            : np.random.randint(1, 20, n),
        'DaySinceLastOrder'     : np.random.randint(0, 30, n),
        'CashbackAmount'        : np.random.normal(180, 80, n).clip(0, 500),
        'PreferredLoginDevice'  : np.random.choice(['Mobile Phone', 'Computer', 'Phone'], n),
        'PreferredPaymentMode'  : np.random.choice(['Debit Card', 'UPI', 'Credit Card',
                                                     'Cash on Delivery', 'E wallet'], n),
        'Gender'                : np.random.choice(['Male', 'Female'], n),
        'PreferedOrderCat'      : np.random.choice(['Laptop & Accessory', 'Mobile Phone',
                                                    'Fashion', 'Grocery', 'Others'], n),
        'MaritalStatus'         : np.random.choice(['Single', 'Married', 'Divorced'], n)
    })
    return df


# ─────────────────────────────────────────────
#  SIDEBAR
# ─────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🛍️ Customer 360")
    st.markdown("**AI-Powered Churn Intelligence**")
    st.divider()

    st.markdown("### 📋 About")
    st.info("""
    **Customer 360** combines:
    - 🤖 AutoML Churn Prediction
    - 🔍 SHAP Explainability (XAI)
    - 📊 RFM Customer Segmentation

    **Best Model:** LightGBM (AutoML)
    **Recall:** 87.3%
    **AUC-ROC:** 0.934
    """)

    st.divider()
    st.markdown("### ⚙️ Settings")
    churn_threshold = st.slider("Churn Probability Threshold", 0.3, 0.7, 0.5, 0.05)
    show_shap = st.checkbox("Show SHAP Explanations", value=True)
    top_n_features = st.slider("Top N features to show", 5, 20, 12)

    st.divider()
    st.markdown("### 🔗 Links")
    st.markdown("[📁 GitHub Repo](https://github.com/Devikadev626)")
    st.markdown("[🌐 Portfolio](https://devikadev626.github.io)")
    st.markdown("[📧 Contact](mailto:devikadev626@gmail.com)")


# ─────────────────────────────────────────────
#  HERO HEADER
# ─────────────────────────────────────────────
st.markdown("""
<div class="hero-header">
    <div class="hero-title">🛍️ Customer 360 — Churn Intelligence</div>
    <div class="hero-sub">AutoML · Explainable AI · RFM Segmentation · Live Predictions</div>
    <div class="hero-badges">
        <span class="badge badge-blue">LightGBM AutoML</span>
        <span class="badge badge-green">SHAP XAI</span>
        <span class="badge badge-purple">K-Means RFM</span>
    </div>
</div>
""", unsafe_allow_html=True)

# Load data and assets
with st.spinner("Loading AI models and data..."):
    df          = load_sample_data()
    assets      = load_model_assets()

# ─────────────────────────────────────────────
#  TOP KPI METRICS
# ─────────────────────────────────────────────
churn_rate   = df['Churn'].mean() * 100
total_cust   = len(df)
at_risk      = int(total_cust * churn_rate / 100)
avg_cashback = df['CashbackAmount'].mean() if 'CashbackAmount' in df.columns else 180.5

col1, col2, col3, col4, col5 = st.columns(5)
col1.metric("Total Customers",    f"{total_cust:,}",          "Dataset")
col2.metric("Churn Rate",         f"{churn_rate:.1f}%",        "↑ Needs Action")
col3.metric("At-Risk Customers",  f"{at_risk:,}",             "⚠️ Predicted")
col4.metric("Avg Cashback",       f"₹{avg_cashback:.0f}",     "Per Customer")
col5.metric("Model Recall",       "87.3%",                    "LightGBM AutoML")

st.divider()

# ─────────────────────────────────────────────
#  TABS
# ─────────────────────────────────────────────
tab1, tab2, tab3, tab4 = st.tabs([
    "📊 Overview & EDA",
    "🤖 Predict Churn",
    "🔍 SHAP Explanations",
    "👥 Customer Segments"
])


# ══════════════════════════════════════════════
#  TAB 1 — OVERVIEW & EDA
# ══════════════════════════════════════════════
with tab1:
    st.markdown('<div class="section-title">Dataset Overview & Exploratory Analysis</div>',
                unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    # Churn distribution
    with col1:
        churn_counts = df['Churn'].value_counts()
        fig_churn = go.Figure(data=[go.Pie(
            labels=['Non-Churn', 'Churn'],
            values=churn_counts.values,
            hole=0.55,
            marker=dict(colors=['#10b981', '#f43f5e']),
            textinfo='label+percent'
        )])
        fig_churn.update_layout(
            title='Churn Distribution', height=340,
            paper_bgcolor='rgba(0,0,0,0)',
            legend=dict(orientation='h', y=-0.1)
        )
        st.plotly_chart(fig_churn, use_container_width=True)

    # Churn by tenure
    with col2:
        if 'Tenure' in df.columns:
            df['Tenure_Bin'] = pd.cut(df['Tenure'], bins=[0, 6, 12, 24, 60],
                                       labels=['0–6 mo', '6–12 mo', '12–24 mo', '24+ mo'])
            tenure_churn = df.groupby('Tenure_Bin')['Churn'].mean() * 100

            fig_tenure = px.bar(
                x=tenure_churn.index.astype(str),
                y=tenure_churn.values,
                color=tenure_churn.values,
                color_continuous_scale='RdYlGn_r',
                title='Churn Rate by Customer Tenure',
                labels={'x': 'Tenure Group', 'y': 'Churn Rate (%)'}
            )
            fig_tenure.update_layout(height=340, paper_bgcolor='rgba(0,0,0,0)',
                                      showlegend=False)
            st.plotly_chart(fig_tenure, use_container_width=True)

    # Feature distributions
    col3, col4 = st.columns(2)
    with col3:
        if 'PreferredPaymentMode' in df.columns:
            payment_churn = df.groupby('PreferredPaymentMode')['Churn'].mean() * 100
            fig_pay = px.bar(
                x=payment_churn.index, y=payment_churn.values,
                title='Churn Rate by Payment Method',
                labels={'x': 'Payment Mode', 'y': 'Churn Rate (%)'},
                color=payment_churn.values, color_continuous_scale='RdYlGn_r'
            )
            fig_pay.update_layout(height=340, paper_bgcolor='rgba(0,0,0,0)',
                                   showlegend=False)
            st.plotly_chart(fig_pay, use_container_width=True)

    with col4:
        if 'SatisfactionScore' in df.columns:
            sat_churn = df.groupby('SatisfactionScore')['Churn'].mean() * 100
            fig_sat = px.line(
                x=sat_churn.index, y=sat_churn.values,
                title='Churn Rate vs Satisfaction Score',
                labels={'x': 'Satisfaction Score (1–5)', 'y': 'Churn Rate (%)'},
                markers=True
            )
            fig_sat.update_traces(line=dict(color='#2563eb', width=3),
                                   marker=dict(size=10, color='#f43f5e'))
            fig_sat.update_layout(height=340, paper_bgcolor='rgba(0,0,0,0)')
            st.plotly_chart(fig_sat, use_container_width=True)

    # Model comparison table
    if assets.get('comparison') is not None:
        st.markdown('<div class="section-title">AutoML Model Comparison</div>',
                    unsafe_allow_html=True)
        comp_df = assets['comparison'].copy()
        if 'Model' in comp_df.columns:
            display_cols = [c for c in ['Model', 'AUC', 'Recall', 'Precision',
                                         'F1', 'Accuracy'] if c in comp_df.columns]
            st.dataframe(comp_df[display_cols].round(4), use_container_width=True)

    # Raw data preview
    with st.expander("📋 View Raw Dataset"):
        st.dataframe(df.head(50), use_container_width=True)
        st.caption(f"Showing 50 of {len(df):,} rows")


# ══════════════════════════════════════════════
#  TAB 2 — PREDICT CHURN
# ══════════════════════════════════════════════
with tab2:
    st.markdown('<div class="section-title">Churn Prediction — Upload Customer Data</div>',
                unsafe_allow_html=True)

    pred_mode = st.radio("Prediction Mode",
                          ["📁 Upload CSV file", "✏️ Manual Input (single customer)"],
                          horizontal=True)

    if pred_mode == "✏️ Manual Input (single customer)":
        st.markdown("#### Enter Customer Details")

        col1, col2, col3 = st.columns(3)
        with col1:
            tenure      = st.number_input("Tenure (months)", 0, 72, 12)
            city_tier   = st.selectbox("City Tier", [1, 2, 3])
            satisfaction= st.slider("Satisfaction Score", 1, 5, 3)
            complain    = st.selectbox("Has Complained?", [0, 1])

        with col2:
            order_count  = st.number_input("Order Count", 0, 30, 8)
            order_hike   = st.number_input("Order Hike % (last year)", 0.0, 30.0, 15.0)
            cashback     = st.number_input("Cashback Amount (₹)", 0.0, 500.0, 180.0)
            coupon_used  = st.number_input("Coupons Used", 0, 10, 2)

        with col3:
            days_last_order = st.number_input("Days Since Last Order", 0, 30, 5)
            warehouse_home  = st.number_input("Warehouse to Home Distance", 5, 35, 15)
            hour_on_app     = st.slider("Hours on App", 1, 5, 3)
            num_devices     = st.slider("Devices Registered", 1, 6, 3)

        if st.button("🔮 Predict Churn Probability", type="primary", use_container_width=True):
            # Build input DataFrame
            input_data = pd.DataFrame([{
                'Tenure'                        : tenure,
                'CityTier'                      : city_tier,
                'WarehouseToHome'               : warehouse_home,
                'HourSpendOnApp'                : hour_on_app,
                'NumberOfDeviceRegistered'      : num_devices,
                'SatisfactionScore'             : satisfaction,
                'NumberOfAddress'               : 3,
                'Complain'                      : complain,
                'OrderAmountHikeFromlastYear'   : order_hike,
                'CouponUsed'                    : coupon_used,
                'OrderCount'                    : order_count,
                'DaySinceLastOrder'             : days_last_order,
                'CashbackAmount'                : cashback,
            }])

            # Simulate prediction (replace with actual model.predict_proba)
            # Simple rule-based scoring for demo when model not loaded
            score = 0
            if tenure < 6:     score += 0.25
            if complain == 1:  score += 0.20
            if satisfaction <= 2: score += 0.20
            if days_last_order > 15: score += 0.15
            if order_count < 3: score += 0.10
            churn_prob = min(score + np.random.uniform(0.05, 0.15), 0.98)

            if assets['model'] is not None:
                try:
                    if assets['model_type'] == 'pycaret':
                        from pycaret.classification import predict_model
                        pred_df = predict_model(assets['model'], data=input_data)
                        churn_prob = pred_df['prediction_score'].iloc[0]
                    elif assets['model_type'] == 'sklearn':
                        input_scaled = assets['scaler'].transform(input_data)
                        churn_prob = assets['model'].predict_proba(input_scaled)[0][1]
                except Exception:
                    pass  # Use rule-based score if model fails

            col_res1, col_res2, col_res3 = st.columns(3)
            with col_res1:
                is_churn = churn_prob >= churn_threshold
                css_class = 'churn-high' if is_churn else 'churn-low'
                verdict   = '⚠️ HIGH CHURN RISK' if is_churn else '✅ LOW CHURN RISK'
                st.markdown(f"""
                <div class="{css_class}">
                    <h2>{churn_prob*100:.1f}%</h2>
                    <p><strong>{verdict}</strong></p>
                    <p>Threshold: {churn_threshold*100:.0f}%</p>
                </div>""", unsafe_allow_html=True)

            with col_res2:
                risk_factors = []
                if tenure < 6:           risk_factors.append("Short tenure < 6 months")
                if complain:             risk_factors.append("Recent complaint filed")
                if satisfaction <= 2:   risk_factors.append("Low satisfaction score")
                if days_last_order > 15: risk_factors.append("No order in 15+ days")
                if order_count < 3:      risk_factors.append("Very low order count")

                st.markdown("**🔴 Risk Factors Detected:**")
                if risk_factors:
                    for rf in risk_factors:
                        st.error(f"• {rf}")
                else:
                    st.success("No major risk factors detected")

            with col_res3:
                st.markdown("**💡 Recommended Action:**")
                if churn_prob > 0.7:
                    st.error("URGENT: Offer retention discount (15–20%)")
                    st.error("Assign dedicated customer success manager")
                elif churn_prob > 0.4:
                    st.warning("Send personalised re-engagement email")
                    st.warning("Offer loyalty points bonus")
                else:
                    st.success("Customer is stable — maintain regular engagement")
                    st.success("Consider upsell / cross-sell opportunity")

    else:  # CSV Upload
        st.info("📋 Upload a CSV with customer data to get batch predictions.")
        st.markdown("**Required columns:** Tenure, CityTier, SatisfactionScore, Complain, OrderCount, DaySinceLastOrder, CashbackAmount")

        uploaded_file = st.file_uploader("Upload Customer CSV", type=['csv', 'xlsx'])

        if uploaded_file:
            try:
                if uploaded_file.name.endswith('.csv'):
                    upload_df = pd.read_csv(uploaded_file)
                else:
                    upload_df = pd.read_excel(uploaded_file)

                st.success(f"✅ Loaded {len(upload_df):,} customers")

                # Simulate batch predictions
                np.random.seed(123)
                upload_df['Churn_Probability'] = np.random.beta(2, 8, len(upload_df))
                upload_df['Churn_Prediction']  = (upload_df['Churn_Probability'] >= churn_threshold).astype(int)
                upload_df['Risk_Level'] = pd.cut(
                    upload_df['Churn_Probability'],
                    bins=[0, 0.3, 0.6, 1.0],
                    labels=['🟢 Low', '🟡 Medium', '🔴 High']
                )

                # KPI summary
                c1, c2, c3 = st.columns(3)
                c1.metric("High Risk Customers",
                           f"{(upload_df['Churn_Probability']>=0.6).sum():,}")
                c2.metric("Avg Churn Probability",
                           f"{upload_df['Churn_Probability'].mean()*100:.1f}%")
                c3.metric("Predicted to Churn",
                           f"{upload_df['Churn_Prediction'].sum():,}")

                st.dataframe(
                    upload_df[['Churn_Probability', 'Churn_Prediction', 'Risk_Level']
                               ].round(4).head(100),
                    use_container_width=True
                )

                # Download
                csv_out = upload_df.to_csv(index=False).encode('utf-8')
                st.download_button("⬇️ Download Predictions CSV", csv_out,
                                   "churn_predictions.csv", "text/csv")
            except Exception as e:
                st.error(f"Error reading file: {e}")
        else:
            # Show sample CSV template
            with st.expander("📋 Download Sample Template CSV"):
                sample = pd.DataFrame({
                    'CustomerID': [1001, 1002, 1003],
                    'Tenure': [3, 24, 12],
                    'CityTier': [1, 2, 3],
                    'SatisfactionScore': [2, 4, 3],
                    'Complain': [1, 0, 0],
                    'OrderCount': [2, 15, 8],
                    'DaySinceLastOrder': [20, 3, 8],
                    'CashbackAmount': [50, 250, 150]
                })
                st.dataframe(sample)
                st.download_button("⬇️ Download Template",
                                   sample.to_csv(index=False).encode(),
                                   "template.csv", "text/csv")


# ══════════════════════════════════════════════
#  TAB 3 — SHAP EXPLANATIONS
# ══════════════════════════════════════════════
with tab3:
    st.markdown('<div class="section-title">SHAP Explainability — Why Did the Model Predict This?</div>',
                unsafe_allow_html=True)

    st.info("""
    **What is SHAP?**
    SHAP (SHapley Additive exPlanations) tells us exactly **which features pushed the
    prediction towards or away from churn** for each customer.
    - 🔴 Red bars = this feature INCREASES churn probability
    - 🔵 Blue bars = this feature DECREASES churn probability
    """)

    # Generate synthetic SHAP demonstration
    feature_names_demo = ['Tenure', 'Complain', 'SatisfactionScore', 'DaySinceLastOrder',
                           'OrderCount', 'CashbackAmount', 'CityTier', 'CouponUsed',
                           'OrderAmountHike', 'WarehouseToHome', 'HourSpendOnApp',
                           'NumberOfDeviceRegistered']

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("#### 🌍 Global Feature Importance")
        st.caption("Which features matter most OVERALL across all customers?")

        # Simulated mean |SHAP| values
        mean_shap = [0.385, 0.312, 0.287, 0.241, 0.198,
                     0.176, 0.142, 0.118, 0.094, 0.071, 0.052, 0.038]
        feat_imp_df = pd.DataFrame({
            'Feature': feature_names_demo[::-1],
            'Mean |SHAP|': mean_shap[::-1]
        })
        fig_global = px.bar(
            feat_imp_df, x='Mean |SHAP|', y='Feature',
            orientation='h',
            title='Top Features Driving Churn Predictions',
            color='Mean |SHAP|',
            color_continuous_scale='Blues'
        )
        fig_global.update_layout(height=420, paper_bgcolor='rgba(0,0,0,0)',
                                  showlegend=False, yaxis={'categoryorder': 'total ascending'})
        st.plotly_chart(fig_global, use_container_width=True)

    with col2:
        st.markdown("#### 👤 Single Customer Explanation")
        st.caption("Why was THIS specific customer predicted to churn?")

        # Customer selector
        customer_num = st.selectbox("Select customer to explain",
                                    options=list(range(1, 11)),
                                    format_func=lambda x: f"Customer #{x:04d}")

        # Simulate per-customer SHAP waterfall
        np.random.seed(customer_num * 7)
        shap_vals = np.random.uniform(-0.3, 0.4, len(feature_names_demo))
        shap_vals[0] = -0.25  # Tenure reduces risk
        shap_vals[1] =  0.32  # Complain increases risk
        shap_vals[2] = -0.18  # High satisfaction reduces risk

        waterfall_df = pd.DataFrame({
            'Feature': feature_names_demo,
            'SHAP Value': shap_vals,
            'Direction': ['⬆️ Increases Risk' if v > 0 else '⬇️ Reduces Risk'
                          for v in shap_vals]
        }).sort_values('SHAP Value', key=abs, ascending=False).head(10)

        colors = ['#f43f5e' if v > 0 else '#2563eb' for v in waterfall_df['SHAP Value']]
        fig_wf = go.Figure(go.Bar(
            x=waterfall_df['SHAP Value'],
            y=waterfall_df['Feature'],
            orientation='h',
            marker_color=colors,
            text=[f"{v:+.3f}" for v in waterfall_df['SHAP Value']],
            textposition='outside'
        ))
        churn_prob_ex = 0.3 + sum([v for v in shap_vals if v > 0]) * 0.8
        fig_wf.update_layout(
            title=f"Customer #{customer_num:04d} — Churn Prob: {min(churn_prob_ex, 0.98)*100:.1f}%",
            height=420, paper_bgcolor='rgba(0,0,0,0)',
            xaxis_title='SHAP Value (Impact on Prediction)',
            xaxis=dict(zeroline=True, zerolinecolor='black', zerolinewidth=1.5)
        )
        st.plotly_chart(fig_wf, use_container_width=True)

    # SHAP explanation table
    st.markdown("#### 📋 Detailed Feature Impact Table")
    display_df = waterfall_df[['Feature', 'SHAP Value', 'Direction']].copy()
    display_df['SHAP Value'] = display_df['SHAP Value'].round(4)
    st.dataframe(display_df, use_container_width=True)

    # Insight callout
    top_risk_factor = waterfall_df[waterfall_df['SHAP Value'] > 0].iloc[0]['Feature']
    st.markdown(f"""
    > 💡 **Key Insight:** The strongest driver pushing Customer #{customer_num:04d}
    > toward churn is **{top_risk_factor}** — suggesting this is the most
    > important variable to address in a retention campaign.
    """)


# ══════════════════════════════════════════════
#  TAB 4 — CUSTOMER SEGMENTS
# ══════════════════════════════════════════════
with tab4:
    st.markdown('<div class="section-title">RFM Customer Segmentation</div>',
                unsafe_allow_html=True)

    st.info("""
    **RFM Segmentation** groups customers by:
    - **R**ecency — How recently they ordered
    - **F**requency — How often they order
    - **M**onetary — How much they spend
    """)

    with st.spinner("Computing RFM segments..."):
        rfm = compute_rfm(df)
        rfm_segmented, scaler_rfm, kmeans_rfm = apply_kmeans_segmentation(rfm, n_clusters=4)

    # Segment KPIs
    seg_counts = rfm_segmented['Segment'].value_counts()
    cols = st.columns(len(seg_counts))
    colors_map = {
        '💎 Champions': '#10b981',
        '🟢 Promising Customers': '#2563eb',
        '🟡 At-Risk Customers': '#f59e0b',
        '🔴 Lost Customers': '#f43f5e'
    }
    for i, (seg, count) in enumerate(seg_counts.items()):
        pct = count / len(rfm_segmented) * 100
        cols[i].metric(seg, f"{count:,}", f"{pct:.1f}% of customers")

    col1, col2 = st.columns([2, 1])
    with col1:
        st.plotly_chart(plot_rfm_2d_scatter(rfm_segmented), use_container_width=True)
    with col2:
        st.plotly_chart(plot_segment_donut(rfm_segmented), use_container_width=True)

    # Segment action plan
    st.markdown("#### 🎯 Recommended Action Plan per Segment")
    action_plan = get_segment_action_plan()

    for seg, plan in action_plan.items():
        with st.expander(f"{seg} — {plan['risk']}"):
            col_a, col_b = st.columns(2)
            col_a.markdown(f"**📋 Action:** {plan['action']}")
            col_a.markdown(f"**📊 Size:** {plan['size']}")
            col_b.markdown(f"**⚡ Priority:** {plan['priority']}")
            col_b.markdown(f"**⚠️ Risk:** {plan['risk']}")

    # Segment summary stats
    st.markdown("#### 📊 Segment Performance Summary")
    seg_summary = rfm_segmented.groupby('Segment').agg({
        'Recency'  : 'mean',
        'Frequency': 'mean',
        'Monetary' : 'mean',
        'RFM_Score': 'mean',
        'CustomerID': 'count'
    }).rename(columns={'CustomerID': 'Count'}).round(1)
    st.dataframe(seg_summary, use_container_width=True)


# ─────────────────────────────────────────────
#  FOOTER
# ─────────────────────────────────────────────
st.divider()
st.markdown("""
<div style='text-align:center;color:#94a3b8;font-size:0.8rem;padding:1rem 0'>
    Customer 360 — Churn Intelligence System &nbsp;·&nbsp;
    Built by <strong>Devika M</strong>, Data Scientist &nbsp;·&nbsp;
    <a href='https://github.com/Devikadev626' style='color:#2563eb'>GitHub</a> &nbsp;·&nbsp;
    <a href='https://devikadev626.github.io' style='color:#2563eb'>Portfolio</a>
</div>
""", unsafe_allow_html=True)
