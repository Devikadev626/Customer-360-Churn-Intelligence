"""
utils/preprocessing.py
Data cleaning and feature engineering for Customer 360 project
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder


def load_data(filepath: str) -> pd.DataFrame:
    """Load the E-Commerce churn dataset."""
    if filepath.endswith('.xlsx'):
        df = pd.read_excel(filepath, sheet_name='E Comm')
    else:
        df = pd.read_csv(filepath)
    print(f"✅ Loaded dataset: {df.shape[0]} rows, {df.shape[1]} columns")
    return df


def basic_info(df: pd.DataFrame) -> None:
    """Print basic dataset information."""
    print("\n📊 Dataset Info:")
    print(f"  Shape        : {df.shape}")
    print(f"  Churn Rate   : {df['Churn'].mean()*100:.1f}%")
    print(f"  Missing vals : {df.isnull().sum().sum()}")
    print(f"\n  Columns: {list(df.columns)}")


def handle_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """
    Handle missing values:
    - Numeric cols → median imputation
    - Categorical cols → mode imputation
    """
    df = df.copy()

    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df.select_dtypes(include=['object']).columns.tolist()

    # Numeric → median
    for col in numeric_cols:
        if df[col].isnull().sum() > 0:
            median_val = df[col].median()
            df[col].fillna(median_val, inplace=True)
            print(f"  Filled {col} with median: {median_val:.2f}")

    # Categorical → mode
    for col in categorical_cols:
        if df[col].isnull().sum() > 0:
            mode_val = df[col].mode()[0]
            df[col].fillna(mode_val, inplace=True)
            print(f"  Filled {col} with mode: {mode_val}")

    print(f"\n✅ Missing values after imputation: {df.isnull().sum().sum()}")
    return df


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create new features from existing data.
    These features often improve model performance significantly.
    """
    df = df.copy()

    # 1. Order frequency ratio
    if 'OrderCount' in df.columns and 'Tenure' in df.columns:
        df['OrderFrequency'] = df['OrderCount'] / (df['Tenure'] + 1)

    # 2. Complaint flag weight
    if 'Complain' in df.columns and 'SatisfactionScore' in df.columns:
        df['ComplainSatisfactionRatio'] = df['Complain'] / (df['SatisfactionScore'] + 1)

    # 3. Cashback to order value ratio
    if 'CashbackAmount' in df.columns and 'OrderAmountHikeFromlastYear' in df.columns:
        df['CashbackOrderRatio'] = df['CashbackAmount'] / (df['OrderAmountHikeFromlastYear'] + 1)

    # 4. Days since last order category
    if 'DaySinceLastOrder' in df.columns:
        df['RecentActivity'] = pd.cut(
            df['DaySinceLastOrder'],
            bins=[-1, 5, 15, 30, 1000],
            labels=['Very Recent', 'Recent', 'Inactive', 'Dormant']
        ).astype(str)

    # 5. High value customer flag
    if 'CashbackAmount' in df.columns:
        df['HighValueCustomer'] = (df['CashbackAmount'] > df['CashbackAmount'].quantile(0.75)).astype(int)

    print(f"✅ Feature engineering complete. New shape: {df.shape}")
    return df


def encode_categoricals(df: pd.DataFrame) -> pd.DataFrame:
    """Label encode all categorical columns."""
    df = df.copy()
    le = LabelEncoder()
    cat_cols = df.select_dtypes(include=['object']).columns.tolist()

    for col in cat_cols:
        df[col] = le.fit_transform(df[col].astype(str))
        print(f"  Encoded: {col}")

    return df


def remove_outliers(df: pd.DataFrame, cols: list, threshold: float = 3.0) -> pd.DataFrame:
    """Remove rows where Z-score > threshold for specified columns."""
    df = df.copy()
    from scipy import stats
    original_len = len(df)

    for col in cols:
        if col in df.columns:
            z_scores = np.abs(stats.zscore(df[col].dropna()))
            df = df[z_scores < threshold]

    removed = original_len - len(df)
    print(f"✅ Removed {removed} outlier rows ({removed/original_len*100:.1f}%)")
    return df


def get_feature_target(df: pd.DataFrame, target_col: str = 'Churn',
                        drop_cols: list = None) -> tuple:
    """Split dataframe into features (X) and target (y)."""
    if drop_cols is None:
        drop_cols = ['CustomerID']

    cols_to_drop = [c for c in drop_cols if c in df.columns] + [target_col]
    X = df.drop(columns=cols_to_drop)
    y = df[target_col]

    print(f"✅ X shape: {X.shape}, y shape: {y.shape}")
    print(f"   Churn rate in y: {y.mean()*100:.1f}%")
    return X, y


def full_preprocessing_pipeline(filepath: str) -> tuple:
    """
    Run the complete preprocessing pipeline.
    Returns: (df_clean, X, y, feature_names)
    """
    print("=" * 50)
    print("🚀 Starting preprocessing pipeline...")
    print("=" * 50)

    df = load_data(filepath)
    basic_info(df)

    print("\n📋 Step 1: Handling missing values...")
    df = handle_missing_values(df)

    print("\n🔧 Step 2: Engineering features...")
    df = engineer_features(df)

    print("\n🏷️ Step 3: Encoding categoricals...")
    df = encode_categoricals(df)

    print("\n📊 Step 4: Splitting features and target...")
    X, y = get_feature_target(df)

    print("\n✅ Preprocessing complete!")
    print("=" * 50)

    return df, X, y, list(X.columns)
