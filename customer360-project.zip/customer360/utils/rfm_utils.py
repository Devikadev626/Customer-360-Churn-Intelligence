"""
utils/rfm_utils.py
RFM Customer Segmentation for Customer 360 project
RFM = Recency · Frequency · Monetary
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import plotly.express as px
import plotly.graph_objects as go


def compute_rfm(df: pd.DataFrame,
                customer_id_col: str = 'CustomerID',
                recency_col: str = 'DaySinceLastOrder',
                frequency_col: str = 'OrderCount',
                monetary_col: str = 'CashbackAmount') -> pd.DataFrame:
    """
    Calculate RFM scores for each customer.

    RFM Explanation:
    - Recency: How recently did they order? (lower = better)
    - Frequency: How often do they order? (higher = better)
    - Monetary: How much do they spend? (higher = better)
    """
    # Check if columns exist, use alternatives if not
    cols_map = {
        'recency': recency_col if recency_col in df.columns else 'DaySinceLastOrder',
        'frequency': frequency_col if frequency_col in df.columns else 'NumberOfOrders',
        'monetary': monetary_col if monetary_col in df.columns else 'OrderAmountHikeFromlastYear'
    }

    rfm = pd.DataFrame()
    rfm['CustomerID'] = df[customer_id_col] if customer_id_col in df.columns else df.index

    # Recency (lower days = more recent = better → invert for scoring)
    if cols_map['recency'] in df.columns:
        rfm['Recency'] = df[cols_map['recency']]
    else:
        rfm['Recency'] = np.random.randint(1, 60, len(df))  # fallback

    # Frequency
    if cols_map['frequency'] in df.columns:
        rfm['Frequency'] = df[cols_map['frequency']]
    else:
        rfm['Frequency'] = np.random.randint(1, 20, len(df))

    # Monetary
    if cols_map['monetary'] in df.columns:
        rfm['Monetary'] = df[cols_map['monetary']]
    else:
        rfm['Monetary'] = np.random.uniform(100, 5000, len(df))

    # Add churn flag if available
    if 'Churn' in df.columns:
        rfm['Churn'] = df['Churn'].values

    # RFM Score (1–5 scale)
    rfm['R_Score'] = pd.qcut(rfm['Recency'], q=5, labels=[5, 4, 3, 2, 1],
                              duplicates='drop').astype(int)
    rfm['F_Score'] = pd.qcut(rfm['Frequency'].rank(method='first'), q=5,
                              labels=[1, 2, 3, 4, 5]).astype(int)
    rfm['M_Score'] = pd.qcut(rfm['Monetary'].rank(method='first'), q=5,
                              labels=[1, 2, 3, 4, 5]).astype(int)
    rfm['RFM_Score'] = rfm['R_Score'] + rfm['F_Score'] + rfm['M_Score']

    print(f"✅ RFM computed for {len(rfm)} customers")
    print(f"   Score range: {rfm['RFM_Score'].min()} – {rfm['RFM_Score'].max()}")
    return rfm


def find_optimal_k(rfm_scaled: np.ndarray, k_range: range = range(2, 9)) -> int:
    """
    Find optimal number of clusters using Elbow + Silhouette methods.
    Returns the recommended k.
    """
    inertias = []
    silhouettes = []

    for k in k_range:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = kmeans.fit_predict(rfm_scaled)
        inertias.append(kmeans.inertia_)
        if k > 1:
            sil = silhouette_score(rfm_scaled, labels)
            silhouettes.append(sil)
        else:
            silhouettes.append(0)

    # Recommend k with highest silhouette score
    best_k = list(k_range)[np.argmax(silhouettes)]
    print(f"✅ Optimal k = {best_k} (Silhouette: {max(silhouettes):.3f})")
    return best_k


def apply_kmeans_segmentation(rfm: pd.DataFrame, n_clusters: int = 4) -> pd.DataFrame:
    """
    Apply K-Means clustering on RFM features.
    Labels clusters with business-meaningful names.
    """
    features = ['Recency', 'Frequency', 'Monetary']
    X = rfm[features].copy()

    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Fit K-Means
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    rfm['Cluster'] = kmeans.fit_predict(X_scaled)

    # Label clusters based on RFM score means
    cluster_summary = rfm.groupby('Cluster').agg({
        'Recency': 'mean',
        'Frequency': 'mean',
        'Monetary': 'mean',
        'RFM_Score': 'mean'
    }).round(1)

    # Sort by RFM_Score to assign labels
    cluster_summary['rank'] = cluster_summary['RFM_Score'].rank()

    # Business labels based on rank
    label_map = {}
    sorted_clusters = cluster_summary['rank'].sort_values()
    labels = ['🔴 Lost Customers', '🟡 At-Risk Customers',
              '🟢 Promising Customers', '💎 Champions']

    # Adjust labels for number of clusters
    if n_clusters == 4:
        for i, cluster_id in enumerate(sorted_clusters.index):
            label_map[cluster_id] = labels[i]
    elif n_clusters == 3:
        for i, cluster_id in enumerate(sorted_clusters.index):
            label_map[cluster_id] = ['🔴 Lost', '🟡 At-Risk', '💎 Champions'][i]
    else:
        for i, cluster_id in enumerate(sorted_clusters.index):
            label_map[cluster_id] = f'Segment {i+1}'

    rfm['Segment'] = rfm['Cluster'].map(label_map)

    # Print summary
    print("\n📊 Segment Summary:")
    summary = rfm.groupby('Segment').agg({
        'Recency': 'mean',
        'Frequency': 'mean',
        'Monetary': 'mean',
        'CustomerID': 'count'
    }).rename(columns={'CustomerID': 'Count'}).round(1)
    print(summary)

    return rfm, scaler, kmeans


def plot_rfm_3d_scatter(rfm: pd.DataFrame) -> go.Figure:
    """
    Interactive 3D scatter plot of customer segments.
    Perfect for the Streamlit dashboard!
    """
    color_map = {
        '💎 Champions': '#10b981',
        '🟢 Promising Customers': '#2563eb',
        '🟡 At-Risk Customers': '#f59e0b',
        '🔴 Lost Customers': '#f43f5e'
    }

    fig = px.scatter_3d(
        rfm,
        x='Recency',
        y='Frequency',
        z='Monetary',
        color='Segment',
        color_discrete_map=color_map,
        hover_data=['RFM_Score'],
        title='Customer Segments — 3D RFM View',
        labels={
            'Recency': 'Recency (Days)',
            'Frequency': 'Order Frequency',
            'Monetary': 'Spend (Cashback)'
        },
        opacity=0.75,
        size_max=8
    )

    fig.update_layout(
        height=550,
        font=dict(family='sans-serif', size=12),
        legend=dict(orientation='v', x=1.0, y=0.9),
        margin=dict(l=0, r=0, t=50, b=0),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    return fig


def plot_rfm_2d_scatter(rfm: pd.DataFrame,
                         x_col: str = 'Frequency',
                         y_col: str = 'Monetary') -> go.Figure:
    """2D scatter plot — cleaner for Streamlit display."""
    color_map = {
        '💎 Champions': '#10b981',
        '🟢 Promising Customers': '#2563eb',
        '🟡 At-Risk Customers': '#f59e0b',
        '🔴 Lost Customers': '#f43f5e'
    }

    fig = px.scatter(
        rfm,
        x=x_col,
        y=y_col,
        color='Segment',
        color_discrete_map=color_map,
        hover_data=['Recency', 'RFM_Score'],
        title=f'Customer Segments: {x_col} vs {y_col}',
        labels={x_col: x_col, y_col: y_col},
        opacity=0.7,
        size='RFM_Score',
        size_max=15
    )

    fig.update_layout(
        height=480,
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        xaxis=dict(showgrid=True, gridcolor='rgba(0,0,0,0.05)'),
        yaxis=dict(showgrid=True, gridcolor='rgba(0,0,0,0.05)'),
        font=dict(family='sans-serif', size=12)
    )
    return fig


def plot_segment_donut(rfm: pd.DataFrame) -> go.Figure:
    """Donut chart showing segment distribution."""
    seg_counts = rfm['Segment'].value_counts()

    colors = ['#10b981', '#2563eb', '#f59e0b', '#f43f5e']

    fig = go.Figure(data=[go.Pie(
        labels=seg_counts.index,
        values=seg_counts.values,
        hole=0.5,
        marker=dict(colors=colors[:len(seg_counts)]),
        textinfo='label+percent',
        hovertemplate='%{label}<br>Count: %{value}<br>%{percent}<extra></extra>'
    )])

    fig.update_layout(
        title='Customer Segment Distribution',
        height=400,
        showlegend=True,
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(family='sans-serif', size=12)
    )
    return fig


def get_segment_action_plan() -> dict:
    """
    Returns recommended marketing actions per segment.
    This is the business insight that impresses interviewers!
    """
    return {
        '💎 Champions': {
            'size': 'Top 20%',
            'action': 'Reward and retain. Offer loyalty rewards, early access, referral bonuses.',
            'risk': 'Low churn risk',
            'priority': '⭐ Very High'
        },
        '🟢 Promising Customers': {
            'size': '~25%',
            'action': 'Nurture with personalised recommendations. Increase purchase frequency.',
            'risk': 'Medium churn risk',
            'priority': '🟡 High'
        },
        '🟡 At-Risk Customers': {
            'size': '~30%',
            'action': 'Re-engage with targeted discounts. Win-back email campaigns.',
            'risk': 'High churn risk',
            'priority': '🔴 Urgent'
        },
        '🔴 Lost Customers': {
            'size': 'Bottom 25%',
            'action': 'Last-chance reactivation offer. If no response, sunset campaign.',
            'risk': 'Very high churn risk',
            'priority': '⚫ Critical'
        }
    }
