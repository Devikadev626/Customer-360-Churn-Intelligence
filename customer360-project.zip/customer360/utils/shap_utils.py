"""
utils/shap_utils.py
SHAP Explainability helpers for Customer 360 project
This is the XAI layer that impresses MNC interviewers!
"""

import shap
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend


def get_shap_explainer(model, X_train: pd.DataFrame):
    """
    Create the right SHAP explainer based on model type.
    TreeExplainer works for LightGBM, XGBoost, Random Forest.
    """
    try:
        # Try TreeExplainer first (fastest for tree-based models)
        explainer = shap.TreeExplainer(model)
        print("✅ Using TreeExplainer (tree-based model detected)")
    except Exception:
        # Fallback to KernelExplainer for other models
        background = shap.sample(X_train, 100)
        explainer = shap.KernelExplainer(model.predict_proba, background)
        print("✅ Using KernelExplainer (fallback)")
    return explainer


def compute_shap_values(explainer, X: pd.DataFrame) -> np.ndarray:
    """Compute SHAP values for a dataset."""
    print(f"🔍 Computing SHAP values for {len(X)} samples...")
    shap_values = explainer.shap_values(X)

    # For binary classification, take class 1 (churn) values
    if isinstance(shap_values, list):
        shap_values = shap_values[1]

    print(f"✅ SHAP values computed. Shape: {shap_values.shape}")
    return shap_values


def plot_global_importance(shap_values: np.ndarray,
                            X: pd.DataFrame,
                            top_n: int = 15,
                            save_path: str = None) -> plt.Figure:
    """
    Global feature importance — shows which features matter most OVERALL.
    Bar chart of mean |SHAP| values.
    """
    fig, ax = plt.subplots(figsize=(10, 6))

    # Calculate mean absolute SHAP values per feature
    mean_shap = np.abs(shap_values).mean(axis=0)
    feature_importance = pd.DataFrame({
        'feature': X.columns,
        'importance': mean_shap
    }).sort_values('importance', ascending=True).tail(top_n)

    # Plot horizontal bar chart
    colors = ['#2563eb' if i >= len(feature_importance) - 3 else '#93c5fd'
              for i in range(len(feature_importance))]
    ax.barh(feature_importance['feature'], feature_importance['importance'],
            color=colors, edgecolor='none')

    ax.set_xlabel('Mean |SHAP Value| (Average Impact on Prediction)', fontsize=11)
    ax.set_title('Top Features Driving Churn Predictions\n(Global Feature Importance via SHAP)',
                 fontsize=13, fontweight='bold', pad=15)
    ax.spines[['top', 'right']].set_visible(False)
    ax.tick_params(axis='both', labelsize=10)

    # Add value labels
    for i, (val, name) in enumerate(zip(feature_importance['importance'],
                                         feature_importance['feature'])):
        ax.text(val + 0.001, i, f'{val:.3f}', va='center', fontsize=9, color='#334155')

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    return fig


def plot_summary_beeswarm(explainer, X: pd.DataFrame,
                           save_path: str = None) -> plt.Figure:
    """
    Beeswarm summary plot — shows direction AND magnitude of each feature.
    Red = high feature value pushes towards churn.
    Blue = low feature value pushes towards churn.
    """
    fig = plt.figure(figsize=(10, 7))
    shap.summary_plot(
        explainer.shap_values(X),
        X,
        plot_type='dot',
        show=False,
        max_display=15,
        color_bar_label='Feature value'
    )
    plt.title('SHAP Beeswarm Plot — Feature Impact Direction',
              fontsize=13, fontweight='bold', pad=15)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    return fig


def plot_waterfall_single_customer(explainer, X_customer: pd.DataFrame,
                                    customer_idx: int = 0,
                                    save_path: str = None) -> plt.Figure:
    """
    Waterfall plot for a SINGLE customer.
    Shows exactly WHY this specific customer was predicted to churn.
    This is the most impressive feature for business presentations!

    Args:
        explainer: fitted SHAP explainer
        X_customer: single row DataFrame (one customer)
        customer_idx: index for display purposes
    """
    explanation = explainer(X_customer)

    # For binary classification models
    if len(explanation.shape) == 3:
        explanation = explanation[:, :, 1]  # Take class 1 (churn)

    fig = plt.figure(figsize=(12, 6))
    shap.waterfall_plot(explanation[0], show=False, max_display=12)
    plt.title(f'Why Customer #{customer_idx} Was Predicted to Churn\n'
              f'(SHAP Waterfall — Individual Explanation)',
              fontsize=12, fontweight='bold', pad=15)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    return fig


def plot_dependence(shap_values: np.ndarray,
                    X: pd.DataFrame,
                    feature: str,
                    interaction_feature: str = 'auto',
                    save_path: str = None) -> plt.Figure:
    """
    Dependence plot — how SHAP value of one feature changes with its value.
    Shows non-linear relationships.
    """
    fig = plt.figure(figsize=(9, 5))
    feature_idx = list(X.columns).index(feature)
    shap.dependence_plot(
        feature_idx,
        shap_values,
        X,
        interaction_index=interaction_feature,
        show=False
    )
    plt.title(f'SHAP Dependence: {feature}', fontsize=13, fontweight='bold')
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    return fig


def get_customer_shap_explanation(explainer, X_customer: pd.DataFrame,
                                   feature_names: list) -> pd.DataFrame:
    """
    Returns a clean DataFrame explaining ONE customer's prediction.
    Perfect for displaying in Streamlit tables.

    Returns:
        DataFrame with columns: Feature, Value, SHAP_Impact, Direction
    """
    explanation = explainer(X_customer)
    if len(explanation.shape) == 3:
        explanation = explanation[:, :, 1]

    shap_vals = explanation[0].values
    feature_vals = X_customer.iloc[0].values

    result = pd.DataFrame({
        'Feature': feature_names,
        'Your Value': feature_vals,
        'Impact on Churn': shap_vals,
        'Direction': ['⬆️ Increases churn risk' if v > 0 else '⬇️ Reduces churn risk'
                      for v in shap_vals]
    })

    # Sort by absolute impact
    result['Abs_Impact'] = result['Impact on Churn'].abs()
    result = result.sort_values('Abs_Impact', ascending=False).drop('Abs_Impact', axis=1)
    result['Impact on Churn'] = result['Impact on Churn'].round(4)
    result['Your Value'] = result['Your Value'].round(3)

    return result.reset_index(drop=True)


def generate_shap_report(explainer, shap_values: np.ndarray,
                          X_test: pd.DataFrame,
                          save_dir: str = 'models/') -> dict:
    """
    Generate and save all SHAP plots for the project.
    Returns dict of file paths.
    """
    import os
    os.makedirs(save_dir, exist_ok=True)
    paths = {}

    print("📊 Generating SHAP report...")

    # 1. Global importance
    p1 = f"{save_dir}shap_global_importance.png"
    plot_global_importance(shap_values, X_test, save_path=p1)
    paths['global'] = p1
    print(f"  ✅ Global importance saved: {p1}")

    # 2. Single customer waterfall (first test sample)
    p2 = f"{save_dir}shap_waterfall_customer0.png"
    plot_waterfall_single_customer(explainer, X_test.iloc[[0]], save_path=p2)
    paths['waterfall'] = p2
    print(f"  ✅ Waterfall plot saved: {p2}")

    print(f"\n✅ SHAP report complete. {len(paths)} plots saved.")
    return paths
